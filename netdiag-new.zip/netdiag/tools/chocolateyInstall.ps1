$ErrorActionPreference = 'Stop'

$packageName = 'netdiag'
$toolsDir = Split-Path -Parent $MyInvocation.MyCommand.Definition

$url64 = 'https://github.com/vectorfault/netdiag/releases/download/v1.0.0/netdiag-1.0.0.zip'
$checksum64 = '83FF99F31C6AD7A3B0242F18ACAC467A49F831F0311B1514B260B3D95EF3FB77'   

Install-ChocolateyZipPackage `
  -PackageName $packageName `
  -UnzipLocation $toolsDir `
  -Url64bit $url64 `
  -Checksum64 $checksum64 `
  -ChecksumType64 'sha256'

$expected = Join-Path $toolsDir 'netdiag.ps1'
$alt1     = Join-Path $toolsDir 'dist\netdiag.ps1'

if (-not (Test-Path $expected) -and (Test-Path $alt1)) {
  Copy-Item $alt1 $expected -Force
}

# Create a shimmed command named "netdiag"
$cmdPath = Join-Path $toolsDir 'netdiag.cmd'
@"
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0netdiag.ps1" %*
"@ | Out-File -FilePath $cmdPath -Encoding ASCII -Force

Install-BinFile -Name 'netdiag' -Path $cmdPath

