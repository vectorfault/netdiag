$ErrorActionPreference = 'Stop'

# Remove shim
Uninstall-BinFile -Name 'netdiag' -Path "$env:ChocolateyInstall\bin\netdiag.exe" 2>$null

# Remove extracted files in tools dir except these scripts
$toolsDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$preserve = @('chocolateyInstall.ps1','chocolateyUninstall.ps1','VERIFICATION.txt')

Get-ChildItem -Path $toolsDir -Force | ForEach-Object {
  if ($preserve -notcontains $_.Name) {
    Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
  }
}
